package org.bpmnwithactiviti.jee6;


public interface Hello {

	public void sayHello(String name);
}
